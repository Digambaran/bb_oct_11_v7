
import React, { lazy } from 'react'
import { Suspense } from 'react'
import env from 'env'

function App() {
  return (
      <h1>Container test pr update test</h1>
  )
}

export default App